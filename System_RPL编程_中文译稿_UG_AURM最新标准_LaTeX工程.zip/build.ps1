param(
    [string]$OutputName = "System_RPL_Chinese_Translation"
)

$ErrorActionPreference = "Stop"
$projectDirectory = Split-Path -Parent $MyInvocation.MyCommand.Path

function Repair-Utf8Intermediate {
    param([string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) {
        return
    }
    $utf8 = [System.Text.UTF8Encoding]::new($false, $false)
    $text = [System.IO.File]::ReadAllText($Path, $utf8)
    $lines = $text -split "`r?`n"
    $cleanLines = @(
        $lines | Where-Object {
            $_.IndexOf([char]0) -lt 0 -and
            $_.IndexOf([char]0xFFFD) -lt 0
        }
    )
    if ($cleanLines.Count -ne $lines.Count) {
        [System.IO.File]::WriteAllText(
            $Path,
            (($cleanLines -join "`n").TrimEnd("`n") + "`n"),
            [System.Text.UTF8Encoding]::new($false)
        )
    }
}

$xelatex = Get-Command xelatex -ErrorAction SilentlyContinue
$tectonicCommand = Get-Command tectonic -ErrorAction SilentlyContinue
$tectonicPath = $null
if ($null -ne $tectonicCommand) {
    $tectonicPath = $tectonicCommand.Source
}
else {
    $workspaceTectonicCandidates = @(
        (Join-Path $projectDirectory "tools\tectonic.exe"),
        (Join-Path $projectDirectory "..\..\..\tmp\tectonic-0.17\tectonic.exe"),
        (Join-Path $projectDirectory "..\..\..\tmp\tectonic\tectonic.exe")
    )
    foreach ($candidate in $workspaceTectonicCandidates) {
        if (Test-Path -LiteralPath $candidate) {
            $tectonicPath = (Resolve-Path -LiteralPath $candidate).Path
            break
        }
    }
}
if ($null -ne $tectonicPath) {
    $xelatex = $null
}

Push-Location $projectDirectory
try {
    if ($null -ne $xelatex) {
        for ($pass = 1; $pass -le 3; $pass++) {
            $savedErrorActionPreference = $ErrorActionPreference
            $ErrorActionPreference = "Continue"
            & $xelatex.Source -interaction=nonstopmode -halt-on-error "-jobname=$OutputName" main.tex
            $compilerExitCode = $LASTEXITCODE
            $ErrorActionPreference = $savedErrorActionPreference
            if ($compilerExitCode -ne 0) {
                throw "XeLaTeX failed on pass $pass"
            }
        }
    }
    elseif ($null -ne $tectonicPath) {
        $workspaceRoot = (Resolve-Path -LiteralPath (Join-Path $projectDirectory "..\..\..")).Path
        $projectLeaf = Split-Path -Leaf $projectDirectory
        $buildDirectory = Join-Path $workspaceRoot ("tmp\sysrpl-latex-build\" + $projectLeaf)
        $fontConfigDirectory = Join-Path $projectDirectory ".fontconfig"
        $fontConfigFile = Join-Path $fontConfigDirectory "fonts.conf"
        $fontCacheDirectory = Join-Path $fontConfigDirectory "cache"
        $lastSuccessfulPdf = Join-Path $buildDirectory ("main.last-good-" + $PID + ".pdf")
        $windowsFontsDirectory = Join-Path $env:WINDIR "Fonts"
        $projectFontsDirectory = Join-Path $projectDirectory "assets\\fonts"
        New-Item -ItemType Directory -Force -Path $buildDirectory | Out-Null
        New-Item -ItemType Directory -Force -Path $fontCacheDirectory | Out-Null
        foreach ($intermediateName in @("main.aux", "main.toc")) {
            $intermediateSource = Join-Path $projectDirectory $intermediateName
            if (Test-Path -LiteralPath $intermediateSource) {
                Repair-Utf8Intermediate -Path $intermediateSource
                Copy-Item -Force -LiteralPath $intermediateSource -Destination $buildDirectory
            }
        }
        $windowsFontsXml = $windowsFontsDirectory.Replace("\", "/")
        $projectFontsXml = $projectFontsDirectory.Replace("\", "/")
        $fontCacheXml = $fontCacheDirectory.Replace("\", "/")
        $fontConfigContent = @"
<?xml version="1.0"?>
<!DOCTYPE fontconfig SYSTEM "urn:fontconfig:fonts.dtd">
<fontconfig>
  <dir>$windowsFontsXml</dir>
  <dir>$projectFontsXml</dir>
  <cachedir>$fontCacheXml</cachedir>
</fontconfig>
"@
        [System.IO.File]::WriteAllText(
            $fontConfigFile,
            $fontConfigContent,
            [System.Text.UTF8Encoding]::new($false)
        )
        $env:FONTCONFIG_FILE = $fontConfigFile
        $env:FONTCONFIG_PATH = $fontConfigDirectory
        for ($pass = 1; $pass -le 3; $pass++) {
            $passSucceeded = $false
            for ($attempt = 1; $attempt -le 3; $attempt++) {
                $savedErrorActionPreference = $ErrorActionPreference
                $ErrorActionPreference = "Continue"
                & $tectonicPath --color never --chatter minimal --reruns 0 --keep-intermediates --keep-logs --outdir $buildDirectory main.tex
                $compilerExitCode = $LASTEXITCODE
                $ErrorActionPreference = $savedErrorActionPreference
                foreach ($intermediateName in @("main.aux", "main.toc")) {
                    $intermediateSource = Join-Path $buildDirectory $intermediateName
                    if (Test-Path -LiteralPath $intermediateSource) {
                        Repair-Utf8Intermediate -Path $intermediateSource
                        Copy-Item -Force -LiteralPath $intermediateSource -Destination $projectDirectory
                    }
                }
                if ($compilerExitCode -eq 0) {
                    $generatedPdf = Join-Path $buildDirectory "main.pdf"
                    if (Test-Path -LiteralPath $generatedPdf) {
                        Copy-Item -Force -LiteralPath $generatedPdf -Destination $lastSuccessfulPdf
                    }
                    $passSucceeded = $true
                    break
                }
            }
            if (-not $passSucceeded) {
                $xdvipdfmxCrashCodes = @(-1073741819, -1073740940)
                if (
                    $pass -ge 2 -and
                    (Test-Path -LiteralPath $lastSuccessfulPdf) -and
                    $xdvipdfmxCrashCodes -contains $compilerExitCode
                ) {
                    Write-Warning (
                        "Tectonic xdvipdfmx crashed on a later stabilization pass; " +
                        "retaining the last successful PDF. Rerun the script if sources changed."
                    )
                    break
                }
                throw "Tectonic failed on pass $pass after 3 attempts"
            }
        }
        if (Test-Path -LiteralPath $lastSuccessfulPdf) {
            Copy-Item -Force -LiteralPath $lastSuccessfulPdf -Destination "$OutputName.pdf"
            foreach ($intermediateName in @("main.aux", "main.toc", "main.log")) {
                $intermediateSource = Join-Path $buildDirectory $intermediateName
                if (Test-Path -LiteralPath $intermediateSource) {
                    Copy-Item -Force -LiteralPath $intermediateSource -Destination $projectDirectory
                }
            }
        }
        else {
            throw "Tectonic did not produce main.pdf"
        }
    }
    else {
        throw "Neither XeLaTeX nor Tectonic is available"
    }
}
finally {
    Pop-Location
}

Get-Item -LiteralPath (Join-Path $projectDirectory "$OutputName.pdf")
