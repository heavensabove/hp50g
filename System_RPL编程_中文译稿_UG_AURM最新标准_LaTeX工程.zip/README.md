# System RPL 编程中文译稿 LaTeX 工程

本工程由 `translations/pages_*.txt` 生成，正文覆盖原书第 1-426 页。
全书采用 2026-07-31 UG/AURM 统一编辑规范：5.5 × 8.2778 英寸页面、
10 pt 正文、247/240 自动行距、公式段落至少 15 pt 防碰撞行距、
2 pt 段后距、零字符间距和章名页脚模板。

工程结构：

- `main.tex`：总入口、版式、字体与超链接设置。
- `main.aux`、`main.toc`：预生成的交叉引用与目录缓存，可由编译脚本刷新。
- `frontmatter.tex`：简要目录和详细目录。
- `content/part01.tex` 至 `part09.tex`：正文九部分。
- `index/name.tex`：按名称排序的词条索引。
- `index/address.tex`：按地址排序的词条索引。
- `assets/`：Futura 字体和原始截图。

使用 Tectonic 或 XeLaTeX 编译；检测到 Tectonic 时优先使用 Tectonic，
以保持与交付 PDF 一致的分页和字体度量：

```powershell
.\build.ps1
```

目录、页码引用和 PDF 书签需要至少两轮编译。`build.ps1` 默认执行三轮。
脚本会自动检测 PATH 中的编译器，也会检测工作区内已下载的
`tmp/tectonic/tectonic.exe` 和 `tmp/tectonic-0.17/tectonic.exe`。
工程移出当前工作区后，可把 `tectonic.exe` 放入工程的 `tools/` 目录。

本工程采用连续流式分页。原书第 1-426 页锚点继续保留，目录、正文交叉引用和双索引均可点击跳转。
